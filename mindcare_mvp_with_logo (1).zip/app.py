from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-for-your-own-deployment"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "mindcare.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS checkins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mood INTEGER NOT NULL CHECK(mood BETWEEN 1 AND 5),
                stress INTEGER NOT NULL CHECK(stress BETWEEN 1 AND 5),
                sleep INTEGER NOT NULL CHECK(sleep BETWEEN 1 AND 5),
                score INTEGER NOT NULL,
                level TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)


def assess_checkin(mood, stress, sleep):
    """
    Educational rule-based indicator only.
    This is NOT a diagnosis, validated screening instrument,
    or prediction of future mental health.
    """
    score = round(((5 - mood) + (stress - 1) + (5 - sleep)) / 12 * 100)
    if score < 30:
        level = "Lower signal"
        message = (
            "Your answers show fewer distress signals in this check-in. "
            "Keep taking care of yourself and check in again when useful."
        )
    elif score < 60:
        level = "Moderate signal"
        message = (
            "You may be experiencing some strain. Consider a gentle "
            "grounding activity or speaking with someone you trust."
        )
    else:
        level = "Higher signal"
        message = (
            "Your answers suggest you may be under significant strain. "
            "If possible, reach out to a trusted person or qualified "
            "mental health professional. You deserve support."
        )
    return score, level, message


@app.route("/")
def index():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM checkins ORDER BY id DESC LIMIT 10"
        ).fetchall()
        total = conn.execute("SELECT COUNT(*) AS n FROM checkins").fetchone()["n"]
    history = [dict(row) for row in rows]
    chart_history = list(reversed(history))
    result = None
    result_id = request.args.get("result", type=int)
    if result_id:
        with get_db() as conn:
            row = conn.execute(
                "SELECT * FROM checkins WHERE id = ?", (result_id,)
            ).fetchone()
        if row:
            score, level, message = assess_checkin(row["mood"], row["stress"], row["sleep"])
            result = {
                "score": row["score"],
                "level": row["level"],
                "message": message,
                "created_at": row["created_at"],
            }
    return render_template(
        "index.html", history=history, chart_history=chart_history,
        total=total, result=result
    )


@app.route("/checkin", methods=["POST"])
def checkin():
    try:
        mood = int(request.form["mood"])
        stress = int(request.form["stress"])
        sleep = int(request.form["sleep"])
    except (ValueError, KeyError):
        flash("Please select all three check-in answers.", "error")
        return redirect(url_for("index", _anchor="checkin"))

    if any(value < 1 or value > 5 for value in (mood, stress, sleep)):
        flash("Invalid check-in values. Please try again.", "error")
        return redirect(url_for("index", _anchor="checkin"))

    score, level, message = assess_checkin(mood, stress, sleep)
    created_at = datetime.now().strftime("%d %b %Y, %I:%M %p")
    with get_db() as conn:
        cursor = conn.execute(
            """INSERT INTO checkins (mood, stress, sleep, score, level, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (mood, stress, sleep, score, level, created_at)
        )
        row_id = cursor.lastrowid
    flash("Your check-in was saved on this device's local project database.", "success")
    return redirect(url_for("index", result=row_id, _anchor="result"))


@app.route("/clear-history", methods=["POST"])
def clear_history():
    with get_db() as conn:
        conn.execute("DELETE FROM checkins")
    flash("Local demo history cleared.", "success")
    return redirect(url_for("index", _anchor="history"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
