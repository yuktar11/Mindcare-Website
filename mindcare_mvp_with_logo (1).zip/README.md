# MindCare MVP

A local Flask prototype for a student hackathon project about mental wellness check-ins and trend awareness.

## Requirements
- Python 3.9+
- Internet connection for Google Fonts and Chart.js CDN (the app itself still runs without the chart CDN, but the chart won't render).

## Run locally

1. Open this folder in VS Code.
2. Open the terminal in this folder.
3. Create and activate a virtual environment (recommended):

   Windows:
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

   macOS/Linux:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install Flask:
   ```bash
   python -m pip install flask
   ```
5. Start the app:
   ```bash
   python app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.

The local SQLite database `mindcare.db` is created automatically after the first run.

## Important limitations
- This is an educational prototype, not a medical device, diagnosis, validated screening instrument, or validated distress prediction model.
- The indicator is a simple hand-designed rule, not trained AI.
- No authentication is included. Anyone with access to the machine/database may be able to see records. Do not deploy this publicly or use real sensitive personal data without appropriate security, consent, privacy review, and clinical/ethical oversight.
- The database is local to the machine running the app.


## Create a public clickable website link
The local address `http://127.0.0.1:5000` works only on the computer running Flask.
To make a shareable public link, push this folder to a GitHub repository and create a Web Service on Render using this repository. Render can build with `pip install -r requirements.txt` and start with `gunicorn app:app`. It will provide a public HTTPS URL after deployment.
Do not deploy with real sensitive mental-health data: this demo has no authentication and is not production-secure.
